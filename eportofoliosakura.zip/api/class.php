<?php
include 'config.php'

/**
 * 
 */
class User
{
	
	function __construct(argument)
	{
		// code...
	}

	public function data_user(){
		$sql = mysqli_query($con,"SELECT * FROM user");
		$query = mysql_query($sql);
        $row = array();
        while($data = mysql_fetch_array($query)){
           $row[] = $data; 
        }
        
        return $row;
	}
}

?>