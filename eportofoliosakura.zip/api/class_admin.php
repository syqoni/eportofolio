<?php

class admin{
    
    public function login($username, $password){ 
        $login="SELECT * FROM admin WHERE username='$username' AND password='$password'";
        $query = mysqli_query($login);
        $row=mysqli_num_rows($query);
        if($row > 0){
            $data= mysqli_fetch_array($query);
            session_start();
            $_SESSION['login']=true;
            $_SESSION['id_admin']=$data['id_admin'];
            //$_SESSION['nama']=$data['nama'];
            $_SESSION['username']=$data['username'];
            $_SESSION['password']=$data['password'];
            //$_SESSION['level']=$data['level'];
            return true;       
        }else{
           return false; 
        }
    }
        
    public function logout(){ 
        session_start();
        session_destroy();
        
    }
    
/*    public function data_user(){
        $sql = "SELECT * FROM user ORDER BY nama ASC";
        $query = mysql_query($sql);
        $row = array();
        while($data = mysql_fetch_array($query)){
           $row[] = $data; 
        }
        
        return $row;
        
    }
    
    public function hapus_user($id){
        $sql = "DELETE FROM user WHERE id_user='$id'";
        $query = mysql_query($sql);
    }
    
    public function simpan_user($id_user,$nama,$username,$password,$level){
        $sql = "INSERT INTO user(id_user,nama,username,password,level) VALUES ('$id_user','$nama','$username','$password','$level')";
        $query = mysql_query($sql);
    }
    
    public function edit_user($id_user){
        $sql = "SELECT * FROM user WHERE id_user='$id_user'";
        $query = mysql_query($sql);
        $row = array();
        while($data = mysql_fetch_array($query)){
           $row[] = $data; 
        }
        
        return $row;
        
    }
    
    public function update_user($id_user,$nama,$username,$password,$level){
        if(!empty($password)){
            $where = ", password='$password'";
        }
        
        $sql = "UPDATE user SET nama='$nama', username='$username', level='$level' $where WHERE id_user='$id_user'";
        $query = mysql_query($sql);
    }

    public function search_user($id_user,$nama,$username,$password,$level){
        $query = $_GET['query'];
        $sql = mysql_query("SELECT * FROM user
            WHERE (`id_user` LIKE '%".$query."%') OR (`nama` LIKE '%".$query."%') OR (`username` LIKE '%".$query."%') OR (`level` LIKE '%".$query."%')") or die(mysql_error());

       if(mysql_num_rows($sql) > 0){ // if one or more rows are returned do following
             
            while($results = mysql_fetch_array($sql)){
            // $results = mysql_fetch_array($raw_results) puts data from database into array, while it's valid it does the loop
             
                echo "<p><h3>".$results['id_user']."</h3>".$results['nama']."<p>".$results['username']."</p>".$results['level']."</p>";
                // posts results gotten from database(title and text) you can also show id ($results['id'])
            }
             
        }
        else{ // if there is no matching rows do following
            echo "No results";
        }
    }
*/
}

?>