<?php
    include '../api/config.php';
    //include '../api/class_user.php';
    //$user = new User();
    //session_start();
    
    session_start();
    if(!isset($_SESSION["login"])){
        header('location: admin_index.php');
        exit;
    }

    include "layout/js_script.php";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>LIHAT DATA NILAI PORTOFOLIO</title>

    <?php 
        include 'layout/css.php';
    ?>

</head>

<body class="animsition">
    <div class="page-wrapper">
        <?php
            include "layout/header_mobile.php";
            include "layout/menu_sidebar.php";
        ?>

        <!-- PAGE CONTAINER-->
        <div class="page-container">
           <?php
                include 'layout/header_desktop.php';
            ?>

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <?php
                        if(isset($_GET['idpilar'],$_GET['nisn'],$_GET['idsem'])){
                                $idsiswa = $_GET['nisn'];
                                $idpilar = $_GET['idpilar'];
                                $idsem = $_GET['idsem'];

                                if($idpilar == 'P01'){
                                    $txpilar = 'AKHLAK DAN LEADERSHIP';
                                }elseif($idpilar == 'P02'){
                                    $txpilar = 'ILMU DAN LOGIKA';
                                }else{
                                    $txpilar = 'BAKAT DAN LIFESKILL';
                                }

                                $view = mysqli_query($con, "SELECT * FROM tbnilaikd 
                                        LEFT JOIN tbsiswa ON tbnilaikd.idsiswa=tbsiswa.idsiswa 
                                        LEFT JOIN tbpilar ON tbnilaikd.idpilar=tbpilar.idpilar
                                        LEFT JOIN tbsemester ON tbnilaikd.idsem=tbsemester.idsem
                                        WHERE tbsiswa.idsiswa='$idsiswa' AND tbpilar.kdpilar='$idpilar' AND tbsemester.idsem='$idsem'")or die(mysqli_error());

                                $view_data=mysqli_fetch_array($view);
                                echo"<div class='col-lg-12'>
                                <div class='card'>
                                    <div class='card-header'>
                                        <strong>PILAR $txpilar</strong>
                                    </div>
                                    <div class='card-body card-block'>";

                                    ?>
                                        <form action="" method="post" enctype="multipart/form-data" class="form-horizontal">
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="idkelas" class="form-control-label">KELAS</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input readonly type="text" id="idkelas" name="idkelas" class="form-control" value="<?php echo $view_data['idkelas'] ?>" >
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="kdpilar" class="form-control-label">PILAR</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input readonly type="text" id="kdpilar" name="kdpilar" class="form-control" value="<?php echo $view_data['kdpilar'] ?>" >
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="idsiswa" class="form-control-label">NISN</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input readonly type="text" id="idsiswa" name="idsiswa" class="form-control" value="<?php echo $idsiswa?>">
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="thn_ajaran" class="form-control-label">Tahun Ajaran/Semester</label>
                                                </div>
                                                <div class="col-4 col-md-4">
                                                    <input readonly type="text" id="thn_ajaran" name="thn_ajaran" class="form-control" value="<?php echo $view_data['thn_ajaran'] ?>">
                                                </div>
                                                <div class="col-4 col-md-4">
                                                    <input readonly type="text" id="semester" name="semester" class="form-control" value="<?php echo $view_data['semester'] ?>">
                                                </div>
                                            </div>
                                            <hr>
                                            <table class="table table-borderless table-data3">
                                                <thead>
                                                    <tr>
                                                        <th>kompetensi dasar</th>
                                                        <th>nilai kompetensi</th>
                                                        <!--<th>kelola</th>-->
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 

                                                    $view = mysqli_query($con, "SELECT * FROM tbnilaikd 
                                                            LEFT JOIN tbsiswa ON tbnilaikd.idsiswa=tbsiswa.idsiswa 
                                                            LEFT JOIN tbpilar ON tbnilaikd.idpilar=tbpilar.idpilar
                                                            LEFT JOIN tbsemester ON tbnilaikd.idsem=tbsemester.idsem
                                                            WHERE tbsiswa.idsiswa='$idsiswa' AND tbpilar.kdpilar='$idpilar' AND tbsemester.idsem='$idsem'")or die(mysqli_error());

                                                    while ($view_kd=mysqli_fetch_array($view)) { ?>
                                                    <tr>
                                                        <td><?php echo $view_kd['kd'] ?></td>
                                                        <td><?php echo $view_kd['nilai_kd'] ?></td>
                                                        <!--<td></td>-->
                                                    </tr>
                                                <?php } ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                            <div class="card-footer">
                                                <a type="button" name="print" class="btn btn-primary btn-sm" href="print_hal1.php?&nisn=<?php echo $idsiswa;?>&idpilar=<?php echo $idpilar;?>&idsem=<?php echo $idsem ?>">Print Portofolio</a>
                                            </div>
                                       </form>
                                        
                                    <?php
                                    echo "</div>
                                    </div>
                                </div>";
                        }else{
                        ?>
                        <div class="user-data m-b-30">
                            <h3 class="title-3 m-b-30">
                                <i class="zmdi zmdi-account-calendar"></i>Data Portofolio</h3>
                                <div class="col-lg-8">
                                <div class="card">
                                    <div class="card-body">
                                        <form action="" method="post">
                                            <div class="row form-group">
                                                <div class="col-md-2">
                                                    <label for="idkelas" class="form-control-label">Kelas</label>
                                                </div>
                                                <div class="col-md-6">
                                                    <select name='idkelas' id='idkelas' class='form-control'>
                                                        <option value="">PILIH KELAS</option>
                                                        <?php

                                                            $tampil=mysqli_query($con,"SELECT * FROM tbkelas ORDER BY idkelas ASC");
                                                                while ($data=mysqli_fetch_array($tampil)) {
                                                        ?>
                                                            <option value="<?php echo $data['idkelas']; ?>"><?php echo $data['nama_kelas']; ?></option>
                                                            
                                                        <?php 
                                                                }
                                                        ?>
                                                        
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col-md-2">
                                                    <label for="idsem" class="form-control-label">TA & SEMESTER</label>
                                                </div>
                                                <div class="col-md-6">
                                                    <select name="idsem" id="idsem" class='form-control'>
                                                        <option value="">PILIH T/A DAN SEMESTER</option>
                                                        <?php

                                                            $tampil=mysqli_query($con,"SELECT * FROM tbsemester");
                                                                while ($data=mysqli_fetch_array($tampil)) {
                                                        ?>
                                                            <option value="<?php echo $data['idsem']; ?>"><?php echo $data['thn_ajaran']; ?> - <?php echo $data['semester']; ?></option>
                                                            
                                                        <?php 
                                                                }
                                                        ?>
                                                        
                                                    </select>
                                                </div>
                                                <div class="col-md-4">
                                                <input type="submit" name="submit" value="Tampil Data" class="btn btn-md btn-info btn-block" >
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="row">
                                
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>no</th>
                                                <th>nisn</th>
                                                <th>nama siswa</th>
                                                <th>view portofolio</th>
                                                <th>kelola</th>

                                            </tr>
                                        </thead>
                                        <tbody>  
                                            <?php
                                                if (isset($_POST['submit'])) {
                                                    $idkelas = $_POST['idkelas'];
                                                    $idsem = $_POST['idsem'];


                                                    if ($idkelas != "") {
                                                        $query = "SELECT * FROM tbsiswa WHERE idkelas='$idkelas'";
                                                        $data = mysqli_query($con,$query);
                                                        $no=1;
                                                        while ($row=mysqli_fetch_array($data)) {
                                                                //$idsiswa = $_POST['idsiswa'];
                                                                //$nama_siswa = $_POST['nama_siswa'];
                                                                //$kd = $_POST['kd'];
                                            ?>
                                                            <tr>
                                                                <td><?php echo $no++ ?></td>
                                                                <td><?php echo $row['idsiswa'];?></td>
                                                                <td><?php echo $row['nama_siswa'];?></td>
                                                                <td>
                                                                    <a type="button" class="btn btn-success btn-sm" href="print_avg.php?&nisn=<?php echo $row['idsiswa'];?>&idsem=<?php echo $idsem ?>">
                                                                    <i class="fa fa-magic"></i>&nbsp; Average
                                                                    </a>
                                                                    <a type="button" class="btn btn-success btn-sm" href="?page=view_porto&nisn=<?php echo $row['idsiswa'];?>&idpilar=P01&idsem=<?php echo $idsem ?>">
                                                                    <i class="fa fa-magic"></i>&nbsp; Pilar I
                                                                    </a>
                                                                    <a type="button" class="btn btn-success btn-sm" href="?page=view_porto&nisn=<?php echo $row['idsiswa'];?>&idpilar=P02&idsem=<?php echo $idsem ?>">
                                                                    <i class="fa fa-magic"></i>&nbsp; Pilar II
                                                                    </a>
                                                                    <a type="button" class="btn btn-success btn-sm" href="?page=view_porto&nisn=<?php echo $row['idsiswa'];?>&idpilar=P03&idsem=<?php echo $idsem ?>">
                                                                    <i class="fa fa-magic"></i>&nbsp; Pilar III
                                                                    </a>
                                                                    <a type="button" class="btn btn-success btn-sm" href="print_all.php?&nisn=<?php echo $row['idsiswa'];?>&idsem=<?php echo $idsem ?>">
                                                                    <i class="fa fa-magic"></i>&nbsp;All
                                                                    </a>
                                                                </td>
                                                                <td><div class="table-data-feature">
                                                                <a class="item" data-toggle="tooltip" data-placement="top" title="Kelola" href="data_porto_add.php">
                                                                    <i class="zmdi zmdi-edit"></i>
                                                                </a></div></td>
                                                            </tr>
                                            <?php
                                                        }
                                                    }
                                                }
                                            
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                            
                        <div class="row">
                            <div class="col-md-12">
                                <div class="copyright">
                                    <p>Copyright © 2018 Colorlib. All rights reserved. Template by <a href="https://colorlib.com">Colorlib</a>.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    

    <?php
    include "layout/js_script.php";
    ?>
    

</body>

</html>
<!-- end document-->
