<?php
	include '../../pages/user/data_user.php';
?>